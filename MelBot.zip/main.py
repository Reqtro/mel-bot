import logging
import os
import requests
from datetime import datetime
from telegram import Update
from telegram.ext import ApplicationBuilder, ContextTypes, MessageHandler, filters

logging.basicConfig(level=logging.INFO)

BOT_TOKEN = os.getenv("BOT_TOKEN")
API_URL = "https://script.google.com/macros/s/AKfycbwwGrQwHCkJqIW_bKMlDk0-50yZEZsJ2MuKGaLdOm675iUlgMM3XC9CCWQkDqUb835C/exec"

def saudacao(nome):
    hora = datetime.now().hour
    if hora < 12:
        return f"Bom dia, {nome}!"
    elif hora < 18:
        return f"Boa tarde, {nome}!"
    else:
        return f"Boa noite, {nome}!"

def contem_termo(texto, termos):
    texto = texto.lower()
    return any(termo in texto for termo in termos)

async def responder(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message is None or update.message.text is None:
        return

    mensagem = update.message.text
    usuario = update.message.from_user.first_name
    if "@mel" not in mensagem.lower():
        return

    if contem_termo(mensagem, ["apresente", "apresenta", "mostrar", "mostre", "quem é", "quem e"]):
        saud = saudacao(f"@{usuario}")
        resposta = (
            f"{saud}\n\n"
            "Eu sou a @Mel, a assistente do Sensor de Nível. Estou aqui para ajudar na obtenção de informações sobre "
            "o nível e o status atual do abastecimento da caixa d'água.\n\n"
            "Para que eu diga qual é o nível atual de água é só me chamar assim:\n"
            "`@Mel qual é o nível?`\n"
            "e para saber qual é o status do abastecimento, me chame assim:\n"
            "`@Mel qual é o abs?`\n"
            "e eu lhe direi.\n\n"
            "Pronto facinho né. Vamos tentar?"
        )
        await update.message.reply_text(resposta, parse_mode="Markdown")
        return

    elif contem_termo(mensagem, ["nível", "nivel"]):
        try:
            resposta_api = requests.get(API_URL)
            dados = resposta_api.json()
            nivel = dados.get("nivel", "desconhecido")
            await update.message.reply_text(f"O nível atual é: {nivel}")
        except Exception:
            await update.message.reply_text("Erro ao buscar o nível da água.")
        return

    elif contem_termo(mensagem, ["abs", "abastecimento", "status abastecimento"]):
        try:
            resposta_api = requests.get(API_URL)
            dados = resposta_api.json()
            abastecimento = dados.get("abastecimento", "desconhecido")
            await update.message.reply_text(f"O status do abastecimento é: {abastecimento}")
        except Exception:
            await update.message.reply_text("Erro ao buscar o status do abastecimento.")
        return

    else:
        await update.message.reply_text("Ixi... Não posso te ajudar com isso...")
        return

if __name__ == "__main__":
    app = ApplicationBuilder().token(BOT_TOKEN).build()
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, responder))
    app.run_polling()
